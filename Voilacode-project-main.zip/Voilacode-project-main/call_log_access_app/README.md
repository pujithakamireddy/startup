# call_log_access_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference

project instructions:
# Call Log Access App

This Flutter app allows you to access and manage call logs on your device. You can view, search, and add new call logs.

## Features

- Retrieve and display call logs.
- Search functionality to filter call logs.
- Add new call logs with caller name, phone number, and call duration and time stamp.
- Sort call logs based on timestamp.
- Centered title for a polished UI.

## Prerequisites

- Flutter,dart-sdk installed on your machine.

