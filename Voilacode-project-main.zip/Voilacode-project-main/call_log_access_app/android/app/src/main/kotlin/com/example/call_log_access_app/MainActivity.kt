package com.example.call_log_access_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
